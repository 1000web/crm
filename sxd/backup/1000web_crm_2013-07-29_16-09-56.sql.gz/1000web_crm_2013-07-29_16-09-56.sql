#SXD20|20010|50529|50410|2013.07.29 16:09:56|1000web_crm|0|20|102|
#TA AuthAssignment`3`16384|AuthItem`22`16384|AuthItemChild`10`16384|Rights`0`16384|tbl_contact_type`7`16384|tbl_customer`6`16384|tbl_customer_contact`3`16384|tbl_migration`2`16384|tbl_organization`18`16384|tbl_organization_contact`7`16384|tbl_organization_group`3`16384|tbl_organization_region`3`16384|tbl_organization_type`3`16384|tbl_product`0`16384|tbl_product_type`0`16384|tbl_profiles`2`16384|tbl_profiles_fields`2`16384|tbl_task_type`9`16384|tbl_user_customer`0`16384|tbl_users`2`16384
#EOH

#	TC`AuthAssignment`utf8_general_ci	;
CREATE TABLE `AuthAssignment` (
  `itemname` varchar(64) CHARACTER SET latin1 NOT NULL,
  `userid` varchar(64) CHARACTER SET latin1 NOT NULL,
  `bizrule` text CHARACTER SET latin1,
  `data` text CHARACTER SET latin1,
  PRIMARY KEY (`itemname`,`userid`),
  CONSTRAINT `AuthAssignment_ibfk_1` FOREIGN KEY (`itemname`) REFERENCES `AuthItem` (`name`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`AuthAssignment`utf8_general_ci	;
INSERT INTO `AuthAssignment` VALUES 
('Admin','1',\N,'N;'),
('Authenticated','2',\N,'N;'),
('Authenticated','3',\N,'N;')	;
#	TC`AuthItem`utf8_general_ci	;
CREATE TABLE `AuthItem` (
  `name` varchar(64) CHARACTER SET latin1 NOT NULL,
  `type` int(11) NOT NULL,
  `description` text CHARACTER SET latin1,
  `bizrule` text CHARACTER SET latin1,
  `data` text CHARACTER SET latin1,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`AuthItem`utf8_general_ci	;
INSERT INTO `AuthItem` VALUES 
('Admin',2,'Administrator',\N,'N;'),
('Authenticated',2,'Registered user',\N,'N;'),
('client.*',0,'client.*',\N,'N;'),
('client.admin',0,'client.admin',\N,'N;'),
('client.create',0,'client.create',\N,'N;'),
('client.delete',0,'client.delete',\N,'N;'),
('client.index',0,'client.index',\N,'N;'),
('client.manager',1,'client.manager',\N,'N;'),
('client.update',0,'client.update',\N,'N;'),
('client.view',0,'client.view',\N,'N;'),
('client.viewer',1,'client.viewer',\N,'N;'),
('Guest',2,'Guest',\N,'N;'),
('organization.*',0,'organization.*',\N,'N;'),
('organization.admin',0,'organization.admin',\N,'N;'),
('organization.create',0,'organization.create',\N,'N;'),
('organization.delete',0,'organization.delete',\N,'N;'),
('organization.index',0,'organization.index',\N,'N;'),
('organization.manager',1,'organization.manager',\N,'N;'),
('organization.update',0,'organization.update',\N,'N;'),
('organization.view',0,'organization.view',\N,'N;'),
('organization.viewer',1,'organization.viewer',\N,'N;'),
('site.*',0,'site.*',\N,'N;')	;
#	TC`AuthItemChild`utf8_general_ci	;
CREATE TABLE `AuthItemChild` (
  `parent` varchar(64) CHARACTER SET latin1 NOT NULL,
  `child` varchar(64) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`parent`,`child`),
  KEY `child` (`child`),
  CONSTRAINT `AuthItemChild_ibfk_1` FOREIGN KEY (`parent`) REFERENCES `AuthItem` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `AuthItemChild_ibfk_2` FOREIGN KEY (`child`) REFERENCES `AuthItem` (`name`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`AuthItemChild`utf8_general_ci	;
INSERT INTO `AuthItemChild` VALUES 
('client.manager','client.*'),
('client.viewer','client.index'),
('Authenticated','client.manager'),
('client.viewer','client.view'),
('Guest','client.viewer'),
('organization.manager','organization.*'),
('organization.viewer','organization.index'),
('Authenticated','organization.manager'),
('organization.viewer','organization.view'),
('Guest','organization.viewer')	;
#	TC`Rights`utf8_general_ci	;
CREATE TABLE `Rights` (
  `itemname` varchar(64) CHARACTER SET latin1 NOT NULL,
  `type` int(11) NOT NULL,
  `weight` int(11) NOT NULL,
  PRIMARY KEY (`itemname`),
  CONSTRAINT `Rights_ibfk_1` FOREIGN KEY (`itemname`) REFERENCES `AuthItem` (`name`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`tbl_contact_type`utf8_general_ci	;
CREATE TABLE `tbl_contact_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `create_user_id` int(11) DEFAULT NULL,
  `update_user_id` int(11) DEFAULT NULL,
  `value` varchar(255) NOT NULL,
  `description` text,
  PRIMARY KEY (`id`),
  KEY `create_user_id` (`create_user_id`),
  KEY `update_user_id` (`update_user_id`),
  CONSTRAINT `tbl_contact_type_ibfk_1` FOREIGN KEY (`create_user_id`) REFERENCES `tbl_users` (`id`),
  CONSTRAINT `tbl_contact_type_ibfk_2` FOREIGN KEY (`update_user_id`) REFERENCES `tbl_users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8	;
#	TD`tbl_contact_type`utf8_general_ci	;
INSERT INTO `tbl_contact_type` VALUES 
(1,1,1,1,1,'Email',''),
(2,1,1,1,1,'Мобильный телефон',''),
(3,1,1,1,1,'Рабочий телефон',''),
(4,1375096249,1375096249,1,1,'Факс',''),
(5,1375096259,1375096259,1,1,'Юридический адрес',''),
(6,1375096271,1375096271,1,1,'Почтовый адрес',''),
(7,1375096284,1375096284,1,1,'Адрес подразделения','')	;
#	TC`tbl_customer`utf8_general_ci	;
CREATE TABLE `tbl_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `create_user_id` int(11) DEFAULT NULL,
  `update_user_id` int(11) DEFAULT NULL,
  `organization_id` int(11) DEFAULT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) DEFAULT NULL,
  `position` varchar(255) DEFAULT NULL,
  `description` text,
  PRIMARY KEY (`id`),
  KEY `organization_id` (`organization_id`),
  KEY `create_user_id` (`create_user_id`),
  KEY `update_user_id` (`update_user_id`),
  CONSTRAINT `tbl_customer_ibfk_3` FOREIGN KEY (`organization_id`) REFERENCES `tbl_organization` (`id`),
  CONSTRAINT `tbl_customer_ibfk_4` FOREIGN KEY (`create_user_id`) REFERENCES `tbl_users` (`id`),
  CONSTRAINT `tbl_customer_ibfk_5` FOREIGN KEY (`update_user_id`) REFERENCES `tbl_users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8	;
#	TD`tbl_customer`utf8_general_ci	;
INSERT INTO `tbl_customer` VALUES 
(1,1374950478,1375104300,1,1,1,'Д.Б.','Мустафаев','',''),
(2,1374951359,1375105262,1,1,1,'Е.','Заровная','',''),
(3,1375003657,1375105314,1,1,1,'Александр Михайлович','Мищенко','Генеральный директор',''),
(4,1375105353,1375105371,1,1,1,'Владимир Александрович','Гордиенко','Технический директор',''),
(5,1375105400,1375105400,1,1,1,'Владимир Николаевич','Гермашов','Коммерческий директор',''),
(6,1375106113,1375106113,1,1,1,'Н.Р.','Хон','','')	;
#	TC`tbl_customer_contact`utf8_general_ci	;
CREATE TABLE `tbl_customer_contact` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `create_user_id` int(11) DEFAULT NULL,
  `update_user_id` int(11) DEFAULT NULL,
  `contact_type_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `value` varchar(255) NOT NULL,
  `description` text,
  PRIMARY KEY (`id`),
  KEY `create_user_id` (`create_user_id`),
  KEY `update_user_id` (`update_user_id`),
  KEY `contact_type_id` (`contact_type_id`),
  KEY `customer_id` (`customer_id`),
  CONSTRAINT `tbl_customer_contact_ibfk_1` FOREIGN KEY (`create_user_id`) REFERENCES `tbl_users` (`id`),
  CONSTRAINT `tbl_customer_contact_ibfk_2` FOREIGN KEY (`update_user_id`) REFERENCES `tbl_users` (`id`),
  CONSTRAINT `tbl_customer_contact_ibfk_3` FOREIGN KEY (`contact_type_id`) REFERENCES `tbl_contact_type` (`id`),
  CONSTRAINT `tbl_customer_contact_ibfk_4` FOREIGN KEY (`customer_id`) REFERENCES `tbl_customer` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8	;
#	TD`tbl_customer_contact`utf8_general_ci	;
INSERT INTO `tbl_customer_contact` VALUES 
(1,1375106535,1375106535,1,1,3,3,'+7 (8639) 27-74-16',''),
(2,1375106573,1375106573,1,1,3,4,'+7 (8639) 27-75-53',''),
(3,1375106602,1375106602,1,1,3,5,'+7 (8639) 27-79-92','')	;
#	TC`tbl_migration`utf8_general_ci	;
CREATE TABLE `tbl_migration` (
  `version` varchar(255) CHARACTER SET latin1 NOT NULL,
  `apply_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`tbl_migration`utf8_general_ci	;
INSERT INTO `tbl_migration` VALUES 
('m110805_153437_installYiiUser',1374928483),
('m110810_162301_userTimestampFix',1374928483)	;
#	TC`tbl_organization`utf8_general_ci	;
CREATE TABLE `tbl_organization` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `create_user_id` int(11) DEFAULT NULL,
  `update_user_id` int(11) DEFAULT NULL,
  `organization_type_id` int(11) NOT NULL,
  `organization_group_id` int(11) NOT NULL,
  `organization_region_id` int(11) NOT NULL,
  `value` varchar(255) NOT NULL,
  `description` text,
  PRIMARY KEY (`id`),
  KEY `create_user_id` (`create_user_id`),
  KEY `update_user_id` (`update_user_id`),
  KEY `organization_type_id` (`organization_type_id`),
  KEY `organization_group_id` (`organization_group_id`),
  KEY `organization_region_id` (`organization_region_id`),
  CONSTRAINT `tbl_organization_ibfk_5` FOREIGN KEY (`create_user_id`) REFERENCES `tbl_users` (`id`),
  CONSTRAINT `tbl_organization_ibfk_6` FOREIGN KEY (`update_user_id`) REFERENCES `tbl_users` (`id`),
  CONSTRAINT `tbl_organization_ibfk_7` FOREIGN KEY (`organization_type_id`) REFERENCES `tbl_organization_type` (`id`),
  CONSTRAINT `tbl_organization_ibfk_8` FOREIGN KEY (`organization_group_id`) REFERENCES `tbl_organization_group` (`id`),
  CONSTRAINT `tbl_organization_ibfk_9` FOREIGN KEY (`organization_region_id`) REFERENCES `tbl_organization_region` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8	;
#	TD`tbl_organization`utf8_general_ci	;
INSERT INTO `tbl_organization` VALUES 
(1,1374951193,1375105059,1,1,1,1,1,'АтомСпецСервис',''),
(2,1374951205,1375027053,1,1,1,1,1,'«NUKEM Technologies GmbH», Германия',''),
(3,1375003924,1375027068,1,1,1,1,1,'РНЦ «Курчатовский институт», Москва',''),
(4,1375027080,1375027080,1,1,1,1,1,'Институты «Атомэнергопроект»: Москва, СПб, Нижний Новгород, Волгоград',''),
(5,1375027136,1375027136,1,1,1,1,1,'Фирма «BROKK», Швеция',''),
(6,1375027144,1375027144,1,1,1,1,1,'ЗАО «Диаконт», Санкт-Петербург',''),
(7,1375027154,1375027154,1,1,1,1,1,'ОАО «ОКБМ Африкантов»',''),
(8,1375027162,1375027162,1,1,1,1,1,'ОАО НПО «ВНИИПТМАШ», Москва',''),
(9,1375027170,1375027170,1,1,1,1,1,'НТЦ «Техноцентр» ЮФУ',''),
(10,1375027177,1375027177,1,1,1,1,1,'ОАО НПО «ЦНИИТМАШ»',''),
(11,1375027186,1375027186,1,1,1,1,1,'ОАО «ВНИИАЭС»',''),
(12,1375027194,1375027194,1,1,1,1,1,'ОАО «Атоммашэкспорт»',''),
(13,1375027202,1375027202,1,1,1,1,1,'ООО «НЗХК-Инструмент»',''),
(14,1375027210,1375027210,1,1,1,1,1,'ООО «Промэнергокомплект»',''),
(15,1375027218,1375027218,1,1,1,1,1,'ОАО ОКБ «Гидропресс»',''),
(16,1375027226,1375027226,1,1,1,1,1,'ООО «Полесье»',''),
(17,1375027234,1375027234,1,1,1,1,1,'ООО «Танаис»',''),
(18,1375105035,1375105035,1,1,1,1,1,'Фирма «ANSALDO NUCLEARE», Италия ','')	;
#	TC`tbl_organization_contact`utf8_general_ci	;
CREATE TABLE `tbl_organization_contact` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `create_user_id` int(11) DEFAULT NULL,
  `update_user_id` int(11) DEFAULT NULL,
  `organization_id` int(11) NOT NULL,
  `contact_type_id` int(11) NOT NULL,
  `value` varchar(255) NOT NULL,
  `description` text,
  PRIMARY KEY (`id`),
  KEY `contact_type_id` (`contact_type_id`),
  KEY `organization_id` (`organization_id`),
  KEY `create_user_id` (`create_user_id`),
  KEY `update_user_id` (`update_user_id`),
  CONSTRAINT `tbl_organization_contact_ibfk_3` FOREIGN KEY (`contact_type_id`) REFERENCES `tbl_contact_type` (`id`),
  CONSTRAINT `tbl_organization_contact_ibfk_4` FOREIGN KEY (`organization_id`) REFERENCES `tbl_organization` (`id`),
  CONSTRAINT `tbl_organization_contact_ibfk_5` FOREIGN KEY (`create_user_id`) REFERENCES `tbl_users` (`id`),
  CONSTRAINT `tbl_organization_contact_ibfk_6` FOREIGN KEY (`update_user_id`) REFERENCES `tbl_users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8	;
#	TD`tbl_organization_contact`utf8_general_ci	;
INSERT INTO `tbl_organization_contact` VALUES 
(1,1375106016,1375106016,1,1,1,5,'Россия, 344037, г. Ростов-на-Дону, пр. Шолохова, д.17',''),
(2,1375106167,1375106167,1,1,1,7,'Россия, 347469, Ростовская обл., г. Волгодонск, улица 8-я Заводская, 23',''),
(3,1375106197,1375106197,1,1,1,6,'Россия, 347360, Ростовская обл., г. Волгодонск, Главпочтамт, а/я 1311',''),
(4,1375106220,1375106220,1,1,1,3,'+7 (8639) 277-999',''),
(5,1375106231,1375106231,1,1,1,4,'+7 (8639) 277-999',''),
(6,1375106251,1375106251,1,1,1,1,'dezaktiv@mail.ru',''),
(7,1375106265,1375106265,1,1,1,1,'kto-acc@mail.ru','')	;
#	TC`tbl_organization_group`utf8_general_ci	;
CREATE TABLE `tbl_organization_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `create_user_id` int(11) DEFAULT NULL,
  `update_user_id` int(11) DEFAULT NULL,
  `value` varchar(255) NOT NULL,
  `description` text,
  PRIMARY KEY (`id`),
  KEY `create_user_id` (`create_user_id`),
  KEY `update_user_id` (`update_user_id`),
  CONSTRAINT `tbl_organization_group_ibfk_1` FOREIGN KEY (`create_user_id`) REFERENCES `tbl_users` (`id`),
  CONSTRAINT `tbl_organization_group_ibfk_2` FOREIGN KEY (`update_user_id`) REFERENCES `tbl_users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8	;
#	TD`tbl_organization_group`utf8_general_ci	;
INSERT INTO `tbl_organization_group` VALUES 
(1,1,1375105705,1,1,'Первая группа ',''),
(2,1,1375105721,1,1,'Вторая группа',''),
(3,1,1375105731,1,1,'Третья группа','')	;
#	TC`tbl_organization_region`utf8_general_ci	;
CREATE TABLE `tbl_organization_region` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `create_user_id` int(11) DEFAULT NULL,
  `update_user_id` int(11) DEFAULT NULL,
  `value` varchar(255) CHARACTER SET utf8mb4 NOT NULL,
  `description` text,
  PRIMARY KEY (`id`),
  KEY `create_user_id` (`create_user_id`),
  KEY `update_user_id` (`update_user_id`),
  CONSTRAINT `tbl_organization_region_ibfk_1` FOREIGN KEY (`create_user_id`) REFERENCES `tbl_users` (`id`),
  CONSTRAINT `tbl_organization_region_ibfk_2` FOREIGN KEY (`update_user_id`) REFERENCES `tbl_users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8	;
#	TD`tbl_organization_region`utf8_general_ci	;
INSERT INTO `tbl_organization_region` VALUES 
(1,1,1,1,1,'Россия',''),
(2,1,1,1,1,'Зарубежье',''),
(3,1375087150,1375087150,1,1,'Украина','')	;
#	TC`tbl_organization_type`utf8_general_ci	;
CREATE TABLE `tbl_organization_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `create_user_id` int(11) DEFAULT NULL,
  `update_user_id` int(11) DEFAULT NULL,
  `value` varchar(255) NOT NULL,
  `description` text,
  PRIMARY KEY (`id`),
  KEY `create_user_id` (`create_user_id`),
  KEY `update_user_id` (`update_user_id`),
  CONSTRAINT `tbl_organization_type_ibfk_1` FOREIGN KEY (`create_user_id`) REFERENCES `tbl_users` (`id`),
  CONSTRAINT `tbl_organization_type_ibfk_2` FOREIGN KEY (`update_user_id`) REFERENCES `tbl_users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8	;
#	TD`tbl_organization_type`utf8_general_ci	;
INSERT INTO `tbl_organization_type` VALUES 
(1,1,1,1,1,'Партнер',''),
(2,1,1,1,1,'Заказчик',''),
(3,1,1,1,1,'Поставщик','')	;
#	TC`tbl_product`utf8_general_ci	;
CREATE TABLE `tbl_product` (
  `id` int(11) NOT NULL,
  `create_time` int(11) NOT NULL,
  `update_time` int(11) NOT NULL,
  `create_user_id` int(11) NOT NULL,
  `update_user_id` int(11) NOT NULL,
  `product_type_id` int(11) NOT NULL,
  `value` varchar(255) NOT NULL,
  `description` text NOT NULL,
  KEY `type` (`product_type_id`),
  KEY `create_user_id` (`create_user_id`),
  KEY `update_user_id` (`update_user_id`),
  KEY `product_type_id` (`product_type_id`),
  CONSTRAINT `tbl_product_ibfk_6` FOREIGN KEY (`product_type_id`) REFERENCES `tbl_product_type` (`id`),
  CONSTRAINT `tbl_product_ibfk_4` FOREIGN KEY (`create_user_id`) REFERENCES `tbl_users` (`id`),
  CONSTRAINT `tbl_product_ibfk_5` FOREIGN KEY (`update_user_id`) REFERENCES `tbl_users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`tbl_product_type`utf8_general_ci	;
CREATE TABLE `tbl_product_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `create_user_id` int(11) DEFAULT NULL,
  `update_user_id` int(11) DEFAULT NULL,
  `value` varchar(255) NOT NULL,
  `description` text,
  PRIMARY KEY (`id`),
  KEY `create_user_id` (`create_user_id`),
  KEY `update_user_id` (`update_user_id`),
  CONSTRAINT `tbl_product_type_ibfk_1` FOREIGN KEY (`create_user_id`) REFERENCES `tbl_users` (`id`),
  CONSTRAINT `tbl_product_type_ibfk_2` FOREIGN KEY (`update_user_id`) REFERENCES `tbl_users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`tbl_profiles`utf8_general_ci	;
CREATE TABLE `tbl_profiles` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  CONSTRAINT `user_profile_id` FOREIGN KEY (`user_id`) REFERENCES `tbl_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8	;
#	TD`tbl_profiles`utf8_general_ci	;
INSERT INTO `tbl_profiles` VALUES 
(1,'Evgeniy','Dmitrichenko'),
(3,'test','test')	;
#	TC`tbl_profiles_fields`utf8_general_ci	;
CREATE TABLE `tbl_profiles_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `varname` varchar(50) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  `field_type` varchar(50) NOT NULL DEFAULT '',
  `field_size` int(3) NOT NULL DEFAULT '0',
  `field_size_min` int(3) NOT NULL DEFAULT '0',
  `required` int(1) NOT NULL DEFAULT '0',
  `match` varchar(255) NOT NULL DEFAULT '',
  `range` varchar(255) NOT NULL DEFAULT '',
  `error_message` varchar(255) NOT NULL DEFAULT '',
  `other_validator` text,
  `default` varchar(255) NOT NULL DEFAULT '',
  `widget` varchar(255) NOT NULL DEFAULT '',
  `widgetparams` text,
  `position` int(3) NOT NULL DEFAULT '0',
  `visible` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8	;
#	TD`tbl_profiles_fields`utf8_general_ci	;
INSERT INTO `tbl_profiles_fields` VALUES 
(1,'first_name','Имя','VARCHAR',255,3,2,'','','Неверное имя (длина должна быть от 3 до 50 символов).','','','','',1,3),
(2,'last_name','Фамилия','VARCHAR',255,3,2,'','','Неверная фамилия (длина должна быть от 3 до 50 символов).','','','','',2,3)	;
#	TC`tbl_task_type`utf8_general_ci	;
CREATE TABLE `tbl_task_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `create_user_id` int(11) DEFAULT NULL,
  `update_user_id` int(11) DEFAULT NULL,
  `value` varchar(255) NOT NULL,
  `description` text,
  PRIMARY KEY (`id`),
  KEY `create_user_id` (`create_user_id`),
  KEY `update_user_id` (`update_user_id`),
  CONSTRAINT `tbl_task_type_ibfk_1` FOREIGN KEY (`create_user_id`) REFERENCES `tbl_users` (`id`),
  CONSTRAINT `tbl_task_type_ibfk_2` FOREIGN KEY (`update_user_id`) REFERENCES `tbl_users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8	;
#	TD`tbl_task_type`utf8_general_ci	;
INSERT INTO `tbl_task_type` VALUES 
(1,1375089924,1375089924,1,1,'Веха','Ключевой момент в ходе выполнения проекта, общая граница двух и более задач.'),
(2,1375090023,1375090023,1,1,'Email входящий','Присланное клиентом письмо по электронной почте.'),
(3,1375090056,1375090056,1,1,'Email исходящий','Нужно отправить клиенту письмо по электронной почте.'),
(4,1375090174,1375090174,1,1,'Контроль исполнения','Контроль исполнения какой-либо задачи.'),
(5,1375090200,1375090230,1,1,'Звонок входящий','Звонок от клиента.'),
(6,1375090215,1375090215,1,1,'Звонок исходящий','Исходящий звонок клиенту.'),
(7,1375090245,1375090245,1,1,'Встреча','Встреча с клиентом.'),
(8,1375090310,1375090669,1,1,'Письмо входящее','Входящее письмо от клиента.'),
(9,1375090325,1375090325,1,1,'Письмо исходящее','Отправка письма клиенту.')	;
#	TC`tbl_user_customer`utf8_general_ci	;
CREATE TABLE `tbl_user_customer` (
  `customer_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`customer_id`,`user_id`),
  KEY `customer_id` (`customer_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `tbl_user_customer_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `tbl_customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `tbl_user_customer_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `tbl_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`tbl_users`utf8_general_ci	;
CREATE TABLE `tbl_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL DEFAULT '',
  `password` varchar(128) NOT NULL DEFAULT '',
  `email` varchar(128) NOT NULL DEFAULT '',
  `activkey` varchar(128) NOT NULL DEFAULT '',
  `superuser` int(1) NOT NULL DEFAULT '0',
  `status` int(1) NOT NULL DEFAULT '0',
  `create_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `lastvisit_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_username` (`username`),
  UNIQUE KEY `user_email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8	;
#	TD`tbl_users`utf8_general_ci	;
INSERT INTO `tbl_users` VALUES 
(1,'admin','b59c67bf196a4758191e42f76670ceba','admin@1000web.ru','0dea9904a1c87af17508927075c2d231',1,1,'2013-07-27 16:34:43','2013-07-29 10:36:36'),
(3,'test','098f6bcd4621d373cade4e832627b4f6','test@1000web.ru','14bb47bd3f709e5e725a3857e42d1934',0,1,'2013-07-28 19:23:42','2013-07-28 18:15:42')	;
