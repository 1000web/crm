#SXD20|20010|50529|50410|2013.07.28 14:00:54|1000web_dogovor|0|10|46|
#TA AuthAssignment`2`16384|AuthItem`22`16384|AuthItemChild`10`16384|Rights`0`16384|tbl_client`3`16384|tbl_migration`2`16384|tbl_organization`3`16384|tbl_profiles`1`16384|tbl_profiles_fields`2`16384|tbl_users`1`16384
#EOH

#	TC`AuthAssignment`utf8_general_ci	;
CREATE TABLE `AuthAssignment` (
  `itemname` varchar(64) CHARACTER SET latin1 NOT NULL,
  `userid` varchar(64) CHARACTER SET latin1 NOT NULL,
  `bizrule` text CHARACTER SET latin1,
  `data` text CHARACTER SET latin1,
  PRIMARY KEY (`itemname`,`userid`),
  CONSTRAINT `AuthAssignment_ibfk_1` FOREIGN KEY (`itemname`) REFERENCES `AuthItem` (`name`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`AuthAssignment`utf8_general_ci	;
INSERT INTO `AuthAssignment` VALUES 
('Admin','1',\N,'N;'),
('Authenticated','2',\N,'N;')	;
#	TC`AuthItem`utf8_general_ci	;
CREATE TABLE `AuthItem` (
  `name` varchar(64) CHARACTER SET latin1 NOT NULL,
  `type` int(11) NOT NULL,
  `description` text CHARACTER SET latin1,
  `bizrule` text CHARACTER SET latin1,
  `data` text CHARACTER SET latin1,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`AuthItem`utf8_general_ci	;
INSERT INTO `AuthItem` VALUES 
('Admin',2,'Administrator',\N,'N;'),
('Authenticated',2,'Registered user',\N,'N;'),
('client.*',0,'client.*',\N,'N;'),
('client.admin',0,'client.admin',\N,'N;'),
('client.create',0,'client.create',\N,'N;'),
('client.delete',0,'client.delete',\N,'N;'),
('client.index',0,'client.index',\N,'N;'),
('client.manager',1,'client.manager',\N,'N;'),
('client.update',0,'client.update',\N,'N;'),
('client.view',0,'client.view',\N,'N;'),
('client.viewer',1,'client.viewer',\N,'N;'),
('Guest',2,'Guest',\N,'N;'),
('organization.*',0,'organization.*',\N,'N;'),
('organization.admin',0,'organization.admin',\N,'N;'),
('organization.create',0,'organization.create',\N,'N;'),
('organization.delete',0,'organization.delete',\N,'N;'),
('organization.index',0,'organization.index',\N,'N;'),
('organization.manager',1,'organization.manager',\N,'N;'),
('organization.update',0,'organization.update',\N,'N;'),
('organization.view',0,'organization.view',\N,'N;'),
('organization.viewer',1,'organization.viewer',\N,'N;'),
('site.*',0,'site.*',\N,'N;')	;
#	TC`AuthItemChild`utf8_general_ci	;
CREATE TABLE `AuthItemChild` (
  `parent` varchar(64) CHARACTER SET latin1 NOT NULL,
  `child` varchar(64) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`parent`,`child`),
  KEY `child` (`child`),
  CONSTRAINT `AuthItemChild_ibfk_1` FOREIGN KEY (`parent`) REFERENCES `AuthItem` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `AuthItemChild_ibfk_2` FOREIGN KEY (`child`) REFERENCES `AuthItem` (`name`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`AuthItemChild`utf8_general_ci	;
INSERT INTO `AuthItemChild` VALUES 
('client.manager','client.*'),
('client.viewer','client.index'),
('Authenticated','client.manager'),
('client.viewer','client.view'),
('Guest','client.viewer'),
('organization.manager','organization.*'),
('organization.viewer','organization.index'),
('Authenticated','organization.manager'),
('organization.viewer','organization.view'),
('Guest','organization.viewer')	;
#	TC`Rights`utf8_general_ci	;
CREATE TABLE `Rights` (
  `itemname` varchar(64) CHARACTER SET latin1 NOT NULL,
  `type` int(11) NOT NULL,
  `weight` int(11) NOT NULL,
  PRIMARY KEY (`itemname`),
  CONSTRAINT `Rights_ibfk_1` FOREIGN KEY (`itemname`) REFERENCES `AuthItem` (`name`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`tbl_client`utf8_general_ci	;
CREATE TABLE `tbl_client` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `create_time` int(11) NOT NULL,
  `update_time` int(11) NOT NULL,
  `create_user` int(11) NOT NULL,
  `update_user` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `create_user` (`create_user`),
  KEY `update_user` (`update_user`),
  CONSTRAINT `tbl_client_ibfk_1` FOREIGN KEY (`create_user`) REFERENCES `tbl_users` (`id`),
  CONSTRAINT `tbl_client_ibfk_2` FOREIGN KEY (`update_user`) REFERENCES `tbl_users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8	;
#	TD`tbl_client`utf8_general_ci	;
INSERT INTO `tbl_client` VALUES 
(1,1374950478,1374950478,1,1,'Первый клиент'),
(2,1374951359,1374951359,1,1,'Второй клиент'),
(3,1375003657,1375003657,1,1,'Второй клиент')	;
#	TC`tbl_migration`utf8_general_ci	;
CREATE TABLE `tbl_migration` (
  `version` varchar(255) CHARACTER SET latin1 NOT NULL,
  `apply_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`tbl_migration`utf8_general_ci	;
INSERT INTO `tbl_migration` VALUES 
('m110805_153437_installYiiUser',1374928483),
('m110810_162301_userTimestampFix',1374928483)	;
#	TC`tbl_organization`utf8_general_ci	;
CREATE TABLE `tbl_organization` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `create_time` int(11) NOT NULL,
  `update_time` int(11) NOT NULL,
  `create_user` int(11) NOT NULL,
  `update_user` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `create_user` (`create_user`),
  KEY `update_user` (`update_user`),
  CONSTRAINT `tbl_organization_ibfk_1` FOREIGN KEY (`create_user`) REFERENCES `tbl_users` (`id`),
  CONSTRAINT `tbl_organization_ibfk_2` FOREIGN KEY (`update_user`) REFERENCES `tbl_users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8	;
#	TD`tbl_organization`utf8_general_ci	;
INSERT INTO `tbl_organization` VALUES 
(1,1374951193,1374951193,1,1,'Первая организация'),
(2,1374951205,1374951205,1,1,'Вторая организация'),
(3,1375003924,1375003924,1,1,'Атоммаш')	;
#	TC`tbl_profiles`utf8_general_ci	;
CREATE TABLE `tbl_profiles` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  CONSTRAINT `user_profile_id` FOREIGN KEY (`user_id`) REFERENCES `tbl_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8	;
#	TD`tbl_profiles`utf8_general_ci	;
INSERT INTO `tbl_profiles` VALUES 
(1,'Administrator','Admin')	;
#	TC`tbl_profiles_fields`utf8_general_ci	;
CREATE TABLE `tbl_profiles_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `varname` varchar(50) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  `field_type` varchar(50) NOT NULL DEFAULT '',
  `field_size` int(3) NOT NULL DEFAULT '0',
  `field_size_min` int(3) NOT NULL DEFAULT '0',
  `required` int(1) NOT NULL DEFAULT '0',
  `match` varchar(255) NOT NULL DEFAULT '',
  `range` varchar(255) NOT NULL DEFAULT '',
  `error_message` varchar(255) NOT NULL DEFAULT '',
  `other_validator` text,
  `default` varchar(255) NOT NULL DEFAULT '',
  `widget` varchar(255) NOT NULL DEFAULT '',
  `widgetparams` text,
  `position` int(3) NOT NULL DEFAULT '0',
  `visible` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8	;
#	TD`tbl_profiles_fields`utf8_general_ci	;
INSERT INTO `tbl_profiles_fields` VALUES 
(1,'first_name','First Name','VARCHAR',255,3,2,'','','Incorrect First Name (length between 3 and 50 characters).','','','','',1,3),
(2,'last_name','Last Name','VARCHAR',255,3,2,'','','Incorrect Last Name (length between 3 and 50 characters).','','','','',2,3)	;
#	TC`tbl_users`utf8_general_ci	;
CREATE TABLE `tbl_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL DEFAULT '',
  `password` varchar(128) NOT NULL DEFAULT '',
  `email` varchar(128) NOT NULL DEFAULT '',
  `activkey` varchar(128) NOT NULL DEFAULT '',
  `superuser` int(1) NOT NULL DEFAULT '0',
  `status` int(1) NOT NULL DEFAULT '0',
  `create_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `lastvisit_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_username` (`username`),
  UNIQUE KEY `user_email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8	;
#	TD`tbl_users`utf8_general_ci	;
INSERT INTO `tbl_users` VALUES 
(1,'admin','b59c67bf196a4758191e42f76670ceba','admin@1000web.ru','0dea9904a1c87af17508927075c2d231',1,1,'2013-07-27 16:34:43','2013-07-28 14:00:03')	;
