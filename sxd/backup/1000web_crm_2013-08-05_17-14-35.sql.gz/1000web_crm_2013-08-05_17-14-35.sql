#SXD20|20010|50529|50410|2013.08.05 17:14:35|1000web_crm|0|36|263|До переименовывания полей в таблицах \ntbl_menu и tbl_item
#TA AuthAssignment`5`16384|AuthItem`27`16384|AuthItemChild`6`16384|Rights`0`16384|tbl_contact_type`9`16384|tbl_contact_type_log`11`16384|tbl_customer`11`16384|tbl_customer_contact`6`16384|tbl_customer_contact_log`6`16384|tbl_customer_log`15`16384|tbl_item`25`16384|tbl_item_log`17`16384|tbl_menu`3`16384|tbl_menu_item`10`16384|tbl_menu_item_log`0`16384|tbl_menu_log`7`16384|tbl_migration`2`16384|tbl_organization`21`16384|tbl_organization_contact`8`16384|tbl_organization_contact_log`2`16384|tbl_organization_group`3`16384|tbl_organization_group_log`7`16384|tbl_organization_log`22`16384|tbl_organization_region`3`16384|tbl_organization_region_log`3`16384|tbl_organization_type`3`16384|tbl_organization_type_log`3`16384|tbl_product`0`16384|tbl_product_type`3`16384|tbl_product_type_log`3`16384|tbl_profiles`4`16384|tbl_profiles_fields`2`16384|tbl_task`0`16384|tbl_task_type`9`16384|tbl_task_type_log`3`16384|tbl_users`4`16384
#EOH

#	TC`AuthAssignment`utf8_general_ci	;
CREATE TABLE `AuthAssignment` (
  `itemname` varchar(64) CHARACTER SET latin1 NOT NULL,
  `userid` varchar(64) CHARACTER SET latin1 NOT NULL,
  `bizrule` text CHARACTER SET latin1,
  `data` text CHARACTER SET latin1,
  PRIMARY KEY (`itemname`,`userid`),
  CONSTRAINT `AuthAssignment_ibfk_1` FOREIGN KEY (`itemname`) REFERENCES `AuthItem` (`name`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`AuthAssignment`utf8_general_ci	;
INSERT INTO `AuthAssignment` VALUES 
('Admin','1',\N,'N;'),
('Authenticated','2',\N,'N;'),
('Authenticated','3',\N,'N;'),
('Authenticated','4',\N,'N;'),
('Authenticated','5',\N,'N;')	;
#	TC`AuthItem`utf8_general_ci	;
CREATE TABLE `AuthItem` (
  `name` varchar(64) CHARACTER SET latin1 NOT NULL,
  `type` int(11) NOT NULL,
  `description` text CHARACTER SET latin1,
  `bizrule` text CHARACTER SET latin1,
  `data` text CHARACTER SET latin1,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`AuthItem`utf8_general_ci	;
INSERT INTO `AuthItem` VALUES 
('Admin',2,'Administrator',\N,'N;'),
('Authenticated',2,'Registered user',\N,'N;'),
('customer.index',0,'customer.index',\N,'N;'),
('customer.view',0,'customer.view',\N,'N;'),
('director',2,'director',\N,'N;'),
('Guest',2,'Guest',\N,'N;'),
('manager',2,'manager',\N,'N;'),
('organization.*',0,'organization.*',\N,'N;'),
('organization.admin',0,'organization.admin',\N,'N;'),
('organization.create',0,'organization.create',\N,'N;'),
('organization.delete',0,'organization.delete',\N,'N;'),
('organization.index',0,'organization.index',\N,'N;'),
('organization.log',0,'organization.log',\N,'N;'),
('organization.manager',1,'organization.manager',\N,'N;'),
('organization.update',0,'organization.update',\N,'N;'),
('organization.view',0,'organization.view',\N,'N;'),
('organization.viewer',1,'organization.viewer',\N,'N;'),
('site.*',0,'site.*',\N,'N;'),
('user.activation.*',0,'user.activation.*',\N,'N;'),
('user.admin.*',0,'user.admin.*',\N,'N;'),
('user.default.*',0,'user.default.*',\N,'N;'),
('user.login.*',0,'user.login.*',\N,'N;'),
('user.logout.*',0,'user.logout.*',\N,'N;'),
('user.profile.*',0,'user.profile.*',\N,'N;'),
('user.recovery.*',0,'user.recovery.*',\N,'N;'),
('user.registration.*',0,'user.registration.*',\N,'N;'),
('user.user.*',0,'user.user.*',\N,'N;')	;
#	TC`AuthItemChild`utf8_general_ci	;
CREATE TABLE `AuthItemChild` (
  `parent` varchar(64) CHARACTER SET latin1 NOT NULL,
  `child` varchar(64) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`parent`,`child`),
  KEY `child` (`child`),
  CONSTRAINT `AuthItemChild_ibfk_1` FOREIGN KEY (`parent`) REFERENCES `AuthItem` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `AuthItemChild_ibfk_2` FOREIGN KEY (`child`) REFERENCES `AuthItem` (`name`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`AuthItemChild`utf8_general_ci	;
INSERT INTO `AuthItemChild` VALUES 
('organization.manager','organization.*'),
('organization.viewer','organization.index'),
('Authenticated','organization.manager'),
('organization.viewer','organization.view'),
('Guest','organization.viewer'),
('Guest','site.*')	;
#	TC`Rights`utf8_general_ci	;
CREATE TABLE `Rights` (
  `itemname` varchar(64) CHARACTER SET latin1 NOT NULL,
  `type` int(11) NOT NULL,
  `weight` int(11) NOT NULL,
  PRIMARY KEY (`itemname`),
  CONSTRAINT `Rights_ibfk_1` FOREIGN KEY (`itemname`) REFERENCES `AuthItem` (`name`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`tbl_contact_type`utf8_general_ci	;
CREATE TABLE `tbl_contact_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `create_user_id` int(11) DEFAULT NULL,
  `update_user_id` int(11) DEFAULT NULL,
  `value` varchar(255) NOT NULL,
  `description` text,
  PRIMARY KEY (`id`),
  KEY `create_user_id` (`create_user_id`),
  KEY `update_user_id` (`update_user_id`),
  CONSTRAINT `tbl_contact_type_ibfk_1` FOREIGN KEY (`create_user_id`) REFERENCES `tbl_users` (`id`),
  CONSTRAINT `tbl_contact_type_ibfk_2` FOREIGN KEY (`update_user_id`) REFERENCES `tbl_users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8	;
#	TD`tbl_contact_type`utf8_general_ci	;
INSERT INTO `tbl_contact_type` VALUES 
(1,1,1375195351,1,1,'Email',''),
(2,1,1375195356,1,1,'Мобильный телефон',''),
(3,1,1375195343,1,1,'Рабочий телефон',''),
(4,1375096249,1375096249,1,1,'Факс',''),
(5,1375096259,1375096259,1,1,'Юридический адрес',''),
(6,1375096271,1375096271,1,1,'Почтовый адрес',''),
(7,1375096284,1375195363,1,1,'Адрес подразделения',''),
(8,1375195301,1375195310,1,1,'Вебсайт',''),
(9,1375195328,1375195328,1,1,'Facebook','')	;
#	TC`tbl_contact_type_log`utf8_general_ci	;
CREATE TABLE `tbl_contact_type_log` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `deleted` tinyint(1) DEFAULT NULL,
  `id` int(11) NOT NULL,
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `create_user_id` int(11) DEFAULT NULL,
  `update_user_id` int(11) DEFAULT NULL,
  `value` varchar(255) NOT NULL,
  `description` text,
  PRIMARY KEY (`log_id`),
  KEY `create_user_id` (`create_user_id`),
  KEY `update_user_id` (`update_user_id`),
  KEY `id` (`id`),
  KEY `deleted` (`deleted`),
  CONSTRAINT `tbl_contact_type_log_ibfk_2` FOREIGN KEY (`create_user_id`) REFERENCES `tbl_users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `tbl_contact_type_log_ibfk_3` FOREIGN KEY (`update_user_id`) REFERENCES `tbl_users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8	;
#	TD`tbl_contact_type_log`utf8_general_ci	;
INSERT INTO `tbl_contact_type_log` VALUES 
(12,\N,1,1375177269,1375177269,1,1,'Email','Электронная почта'),
(13,\N,2,1375177290,1375177290,1,1,'Мобильный телефон','Телефон с возможностью приема смс.'),
(14,\N,3,1375177304,1375177304,1,1,'Рабочий телефон','Городской номер телефона.'),
(15,\N,7,1375177332,1375177332,1,1,'Адрес подразделения','Адрес фактического местонахождения подразделения.'),
(16,\N,8,1375195301,1375195301,1,1,'Вебсайт','Адрес сайта'),
(17,\N,8,1375195310,1375195310,1,1,'Вебсайт',''),
(18,\N,9,1375195328,1375195328,1,1,'Facebook',''),
(19,\N,3,1375195343,1375195343,1,1,'Рабочий телефон',''),
(20,\N,1,1375195351,1375195351,1,1,'Email',''),
(21,\N,2,1375195356,1375195356,1,1,'Мобильный телефон',''),
(22,\N,7,1375195363,1375195363,1,1,'Адрес подразделения','')	;
#	TC`tbl_customer`utf8_general_ci	;
CREATE TABLE `tbl_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `create_user_id` int(11) DEFAULT NULL,
  `update_user_id` int(11) DEFAULT NULL,
  `organization_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) DEFAULT NULL,
  `position` varchar(255) DEFAULT NULL,
  `description` text,
  PRIMARY KEY (`id`),
  KEY `organization_id` (`organization_id`),
  KEY `create_user_id` (`create_user_id`),
  KEY `update_user_id` (`update_user_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `tbl_customer_ibfk_3` FOREIGN KEY (`organization_id`) REFERENCES `tbl_organization` (`id`),
  CONSTRAINT `tbl_customer_ibfk_4` FOREIGN KEY (`create_user_id`) REFERENCES `tbl_users` (`id`),
  CONSTRAINT `tbl_customer_ibfk_5` FOREIGN KEY (`update_user_id`) REFERENCES `tbl_users` (`id`),
  CONSTRAINT `tbl_customer_ibfk_6` FOREIGN KEY (`user_id`) REFERENCES `tbl_users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8	;
#	TD`tbl_customer`utf8_general_ci	;
INSERT INTO `tbl_customer` VALUES 
(1,1374950478,1375104300,1,1,1,\N,'Д.Б.','Мустафаев','',''),
(2,1374951359,1375105262,1,1,1,\N,'Е.','Заровная','',''),
(3,1375003657,1375105314,1,1,1,\N,'Александр Михайлович','Мищенко','Генеральный директор',''),
(4,1375105353,1375105371,1,1,1,\N,'Владимир Александрович','Гордиенко','Технический директор',''),
(5,1375105400,1375105400,1,1,1,\N,'Владимир Николаевич','Гермашов','Коммерческий директор',''),
(6,1375106113,1375106113,1,1,1,\N,'Н.Р.','Хон','',''),
(7,1375108509,1375108509,1,1,1,\N,'Е.Ю.','Воронова','',''),
(8,1375108554,1375108554,1,1,1,\N,'С.Г.','Александрова','',''),
(10,1375528929,1375605899,1,1,11,\N,'Имя','Фамилия','Должность',''),
(11,1375529430,1375529430,1,1,25,\N,'Евгений','Дмитриченко','Программист',''),
(12,1375605930,1375605930,1,1,25,\N,'Имя2','Фамилия2','Должность2','')	;
#	TC`tbl_customer_contact`utf8_general_ci	;
CREATE TABLE `tbl_customer_contact` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `create_user_id` int(11) DEFAULT NULL,
  `update_user_id` int(11) DEFAULT NULL,
  `contact_type_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `value` varchar(255) NOT NULL,
  `description` text,
  PRIMARY KEY (`id`),
  KEY `create_user_id` (`create_user_id`),
  KEY `update_user_id` (`update_user_id`),
  KEY `contact_type_id` (`contact_type_id`),
  KEY `customer_id` (`customer_id`),
  CONSTRAINT `tbl_customer_contact_ibfk_1` FOREIGN KEY (`create_user_id`) REFERENCES `tbl_users` (`id`),
  CONSTRAINT `tbl_customer_contact_ibfk_2` FOREIGN KEY (`update_user_id`) REFERENCES `tbl_users` (`id`),
  CONSTRAINT `tbl_customer_contact_ibfk_3` FOREIGN KEY (`contact_type_id`) REFERENCES `tbl_contact_type` (`id`),
  CONSTRAINT `tbl_customer_contact_ibfk_4` FOREIGN KEY (`customer_id`) REFERENCES `tbl_customer` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8	;
#	TD`tbl_customer_contact`utf8_general_ci	;
INSERT INTO `tbl_customer_contact` VALUES 
(1,1375106535,1375106535,1,1,3,3,'+7 (8639) 27-74-16',''),
(2,1375106573,1375106573,1,1,3,4,'+7 (8639) 27-75-53',''),
(3,1375106602,1375106602,1,1,3,5,'+7 (8639) 27-79-92',''),
(4,1375529452,1375529452,1,1,1,11,'admin@1000web.ru',''),
(5,1375529468,1375529468,1,1,2,11,'+79185569410',''),
(6,1375529484,1375529484,1,1,8,11,'http://1000web.ru','')	;
#	TC`tbl_customer_contact_log`utf8_general_ci	;
CREATE TABLE `tbl_customer_contact_log` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `deleted` tinyint(1) DEFAULT NULL,
  `id` int(11) NOT NULL,
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `create_user_id` int(11) DEFAULT NULL,
  `update_user_id` int(11) DEFAULT NULL,
  `contact_type_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `value` varchar(255) NOT NULL,
  `description` text,
  PRIMARY KEY (`log_id`),
  KEY `create_user_id` (`create_user_id`),
  KEY `update_user_id` (`update_user_id`),
  KEY `contact_type_id` (`contact_type_id`),
  KEY `customer_id` (`customer_id`),
  KEY `deleted` (`deleted`,`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8	;
#	TD`tbl_customer_contact_log`utf8_general_ci	;
INSERT INTO `tbl_customer_contact_log` VALUES 
(1,\N,4,1375183937,1375183937,1,1,1,1,'1',''),
(2,\N,4,1375183958,1375183958,1,1,2,1,'2',''),
(3,1,4,1375183967,1375183967,1,1,2,1,'2',''),
(4,\N,4,1375529452,1375529452,1,1,1,11,'admin@1000web.ru',''),
(5,\N,5,1375529468,1375529468,1,1,2,11,'+79185569410',''),
(6,\N,6,1375529484,1375529484,1,1,8,11,'http://1000web.ru','')	;
#	TC`tbl_customer_log`utf8_general_ci	;
CREATE TABLE `tbl_customer_log` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `deleted` tinyint(1) DEFAULT NULL,
  `id` int(11) NOT NULL,
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `create_user_id` int(11) DEFAULT NULL,
  `update_user_id` int(11) DEFAULT NULL,
  `organization_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) DEFAULT NULL,
  `position` varchar(255) DEFAULT NULL,
  `description` text,
  PRIMARY KEY (`log_id`),
  KEY `organization_id` (`organization_id`),
  KEY `create_user_id` (`create_user_id`),
  KEY `update_user_id` (`update_user_id`),
  KEY `user_id` (`user_id`),
  KEY `deleted` (`deleted`,`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8	;
#	TD`tbl_customer_log`utf8_general_ci	;
INSERT INTO `tbl_customer_log` VALUES 
(1,\N,9,1375177693,1375177693,1,1,1,\N,'Newsssss','111','222','desc'),
(2,\N,9,1375177709,1375177709,1,1,1,\N,'Newssssser','eeee','222eeee','desc'),
(3,\N,10,1375177811,1375177811,1,1,1,\N,'111','111','111','111'),
(4,\N,10,1375177819,1375177819,1,1,1,\N,'222','222','222','222'),
(5,1,10,1375177822,1375177822,1,1,1,\N,'222','222','222','222'),
(6,\N,9,1375527190,1375527190,1,1,1,\N,'1','1','1','1'),
(7,1,9,1375527199,1375527199,1,1,1,\N,'1','1','1','1'),
(8,\N,10,1375528929,1375528929,1,1,2,\N,'111111','11111','1111','111'),
(9,\N,10,1375529054,1375529054,1,1,11,\N,'111111','11111','1111','111'),
(10,\N,11,1375529430,1375529430,1,1,25,\N,'Евгений','Дмитриченко','Программист',''),
(11,\N,10,1375603605,1375603605,1,1,11,\N,'111111','11111','1111',''),
(12,\N,10,1375605872,1375605872,1,1,11,\N,'1','','',''),
(13,\N,10,1375605888,1375605888,1,1,11,\N,'Имя','Фамилия','',''),
(14,\N,10,1375605899,1375605899,1,1,11,\N,'Имя','Фамилия','Должность',''),
(15,\N,12,1375605930,1375605930,1,1,25,\N,'Имя2','Фамилия2','Должность2','')	;
#	TC`tbl_item`utf8_general_ci	;
CREATE TABLE `tbl_item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT NULL,
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `create_user_id` int(11) DEFAULT NULL,
  `update_user_id` int(11) DEFAULT NULL,
  `module` varchar(64) DEFAULT NULL,
  `controller` varchar(64) DEFAULT NULL,
  `action` varchar(64) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `h1` varchar(255) DEFAULT NULL,
  `value` varchar(255) NOT NULL,
  `description` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `module` (`module`,`controller`,`action`),
  KEY `parent_id` (`parent_id`),
  KEY `create_user_id` (`create_user_id`),
  KEY `update_user_id` (`update_user_id`),
  KEY `controller` (`controller`),
  KEY `action` (`action`),
  CONSTRAINT `tbl_item_ibfk_3` FOREIGN KEY (`parent_id`) REFERENCES `tbl_item` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `tbl_item_ibfk_4` FOREIGN KEY (`create_user_id`) REFERENCES `tbl_users` (`id`),
  CONSTRAINT `tbl_item_ibfk_5` FOREIGN KEY (`update_user_id`) REFERENCES `tbl_users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8	;
#	TD`tbl_item`utf8_general_ci	;
INSERT INTO `tbl_item` VALUES 
(1,\N,\N,1375714050,1,1,'','customer','index','Клиенты','Клиенты','Клиенты','Клиенты - это люди в компании, с которыми вы общаетесь и взаимодействуете в рамках достижения бизнес-задач'),
(2,\N,\N,\N,1,1,\N,'organization','index','','','Организации',' Организации - это компании или корпоративные отделы, с которыми вы имеете деловые отношения'),
(3,\N,\N,\N,1,1,\N,'task','index','','','Задачи','Задачи - перечень или реестр задач, событий и звонков, связанных с записями CRM, относящимися к различным модулям'),
(4,\N,\N,1375711644,1,1,'','deal','index','Потенциальные сделки','Потенциальные сделки','Сделки','Потенциальные сделки - это сделки с организациями или людьми, приносящие доход вашей организации.'),
(5,\N,\N,\N,1,1,\N,'glossary','index','','','Справочники',\N),
(6,\N,\N,\N,1,1,\N,'profile','profile','','','Профиль',\N),
(8,1,\N,1375713035,1,1,'','customer','create','Создать Клиента','Создать Клиента','Создать Клиента',''),
(9,1,\N,1375713656,1,1,'','customerContact','index','Контакты Клиентов','Контакты Клиентов','Контакты Клиентов',''),
(11,2,\N,1375711555,1,1,'','organization','create','Создать Организацию','Создать Организацию','Создать',''),
(13,3,\N,1375711575,1,1,'','task','create','Создать Задачу','Создать Задачу','Создать',''),
(15,4,\N,\N,1,1,\N,'deal','create','','','Создать Сделку',\N),
(16,5,\N,\N,1,1,\N,'contactType','index','','','Типы контактов',\N),
(17,5,\N,\N,1,1,\N,'taskType','index','','','Типы задач',\N),
(18,5,\N,\N,1,1,\N,'organizationType','index','','','Типы организаций',\N),
(19,5,\N,\N,1,1,\N,'organizationRegion','index','','','Регионы организаций',\N),
(20,5,\N,\N,1,1,\N,'organizationGroup','index','','','Группы организаций',\N),
(21,5,\N,\N,1,1,\N,'organizationContact','index','','','Контакты организаций',\N),
(23,6,\N,\N,1,1,\N,'user','logout','','','Выйти',\N),
(24,1,1375711701,1375713524,1,1,'','customer','view','Просмотр Клиента','Просмотр Клиента','Просмотр Клиента',''),
(25,1,1375713576,1375713576,1,1,'','customer','admin','Управление Клиентами','Управление Клиентами','Управление Клиентами',''),
(26,1,1375713612,1375713612,1,1,'','customer','update','Редактирование Клиента','Редактирование Клиента','Редактирование Клиента',''),
(31,16,1375713830,1375713954,1,1,'','contactType','view','Просмотр Типа контакта','Просмотр Тип контакта','Просмотр Типа контакта',''),
(32,16,1375714008,1375714008,1,1,'','contactType','update','Редактирование Типа контакта','Редактирование Типа контакта','Редактирование Типа контакта',''),
(33,16,1375714091,1375714091,1,1,'','contactType','create','Создать Тип контакта','Создать Тип контакта','Создать Тип контакта',''),
(34,16,1375714138,1375714138,1,1,'','contactType','admin','Управление Типами контактов','Управление Типами контактов','Управление Типами контактов','')	;
#	TC`tbl_item_log`utf8_general_ci	;
CREATE TABLE `tbl_item_log` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `deleted` tinyint(1) DEFAULT NULL,
  `id` int(11) NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `create_user_id` int(11) DEFAULT NULL,
  `update_user_id` int(11) DEFAULT NULL,
  `module` varchar(64) DEFAULT NULL,
  `controller` varchar(64) DEFAULT NULL,
  `action` varchar(64) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `h1` varchar(255) DEFAULT NULL,
  `value` varchar(255) NOT NULL,
  `description` text,
  PRIMARY KEY (`log_id`),
  KEY `parent_id` (`parent_id`),
  KEY `create_user_id` (`create_user_id`),
  KEY `update_user_id` (`update_user_id`),
  KEY `controller` (`controller`),
  KEY `action` (`action`),
  KEY `deleted` (`deleted`),
  KEY `id` (`id`),
  KEY `module` (`module`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8	;
#	TD`tbl_item_log`utf8_general_ci	;
INSERT INTO `tbl_item_log` VALUES 
(1,\N,11,2,1375711555,1375711555,1,1,'','organization','create','Создать Организацию','Создать Организацию','Создать',''),
(2,\N,13,3,1375711575,1375711575,1,1,'','task','create','Создать Задачу','Создать Задачу','Создать',''),
(3,\N,9,1,1375711596,1375711596,1,1,'','customerContact','index','Контакты Клиентов','Контакты Клиентов','Контакты',''),
(4,\N,4,\N,1375711644,1375711644,1,1,'','deal','index','Потенциальные сделки','Потенциальные сделки','Сделки','Потенциальные сделки - это сделки с организациями или людьми, приносящие доход вашей организации.'),
(5,\N,24,\N,1375711701,1375711701,1,1,'','customer','view','','','Просмотр',''),
(6,\N,8,1,1375713035,1375713035,1,1,'','customer','create','Создать Клиента','Создать Клиента','Создать Клиента',''),
(7,\N,1,\N,1375713057,1375713057,1,1,'','customer','index','Список Клиентов','Список Клиентов','Список Клиентов','Клиенты - это люди в компании, с которыми вы общаетесь и взаимодействуете в рамках достижения бизнес-задач'),
(9,\N,24,1,1375713524,1375713524,1,1,'','customer','view','Просмотр Клиента','Просмотр Клиента','Просмотр Клиента',''),
(10,\N,25,1,1375713576,1375713576,1,1,'','customer','admin','Управление Клиентами','Управление Клиентами','Управление Клиентами',''),
(11,\N,26,1,1375713612,1375713612,1,1,'','customer','update','Редактирование Клиента','Редактирование Клиента','Редактирование Клиента',''),
(12,\N,9,1,1375713656,1375713656,1,1,'','customerContact','index','Контакты Клиентов','Контакты Клиентов','Контакты Клиентов',''),
(13,\N,31,16,1375713830,1375713830,1,1,'','contactType','view','Просмотр Контакта Клиента','Просмотр Контакта Клиента','Просмотр Контакта Клиента',''),
(14,\N,31,16,1375713954,1375713954,1,1,'','contactType','view','Просмотр Типа контакта','Просмотр Тип контакта','Просмотр Типа контакта',''),
(15,\N,32,16,1375714008,1375714008,1,1,'','contactType','update','Редактирование Типа контакта','Редактирование Типа контакта','Редактирование Типа контакта',''),
(16,\N,1,\N,1375714050,1375714050,1,1,'','customer','index','Клиенты','Клиенты','Клиенты','Клиенты - это люди в компании, с которыми вы общаетесь и взаимодействуете в рамках достижения бизнес-задач'),
(17,\N,33,16,1375714091,1375714091,1,1,'','contactType','create','Создать Тип контакта','Создать Тип контакта','Создать Тип контакта',''),
(18,\N,34,16,1375714138,1375714138,1,1,'','contactType','admin','Управление Типами контактов','Управление Типами контактов','Управление Типами контактов','')	;
#	TC`tbl_menu`utf8_general_ci	;
CREATE TABLE `tbl_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `create_user_id` int(11) DEFAULT NULL,
  `update_user_id` int(11) DEFAULT NULL,
  `value` varchar(64) NOT NULL,
  `description` text,
  PRIMARY KEY (`id`),
  KEY `create_user` (`create_user_id`),
  KEY `update_user` (`update_user_id`),
  KEY `create_user_id` (`create_user_id`),
  KEY `update_user_id` (`update_user_id`),
  KEY `name` (`value`),
  CONSTRAINT `tbl_menu_ibfk_1` FOREIGN KEY (`create_user_id`) REFERENCES `tbl_users` (`id`),
  CONSTRAINT `tbl_menu_ibfk_2` FOREIGN KEY (`update_user_id`) REFERENCES `tbl_users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8	;
#	TD`tbl_menu`utf8_general_ci	;
INSERT INTO `tbl_menu` VALUES 
(1,\N,1375645721,1,1,'top_menu','Верхнее меню'),
(2,\N,1375645738,1,1,'bottom_menu','Нижнее меню'),
(3,1375692666,1375692666,1,1,'home_menu','Главная страница')	;
#	TC`tbl_menu_item`utf8_general_ci	;
CREATE TABLE `tbl_menu_item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `create_user_id` int(11) DEFAULT NULL,
  `update_user_id` int(11) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `menu_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `prior` tinyint(4) NOT NULL,
  `visible` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `visible` (`visible`),
  KEY `prior` (`prior`),
  KEY `parent_id` (`parent_id`),
  KEY `menu_id` (`menu_id`),
  KEY `item_id` (`item_id`),
  KEY `create_user_id` (`create_user_id`),
  KEY `update_user_id` (`update_user_id`),
  CONSTRAINT `tbl_menu_item_ibfk_7` FOREIGN KEY (`update_user_id`) REFERENCES `tbl_users` (`id`),
  CONSTRAINT `tbl_menu_item_ibfk_3` FOREIGN KEY (`parent_id`) REFERENCES `tbl_menu_item` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `tbl_menu_item_ibfk_4` FOREIGN KEY (`menu_id`) REFERENCES `tbl_menu` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `tbl_menu_item_ibfk_5` FOREIGN KEY (`item_id`) REFERENCES `tbl_item` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `tbl_menu_item_ibfk_6` FOREIGN KEY (`create_user_id`) REFERENCES `tbl_users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8	;
#	TD`tbl_menu_item`utf8_general_ci	;
INSERT INTO `tbl_menu_item` VALUES 
(1,\N,\N,\N,\N,\N,1,1,1,1),
(2,\N,\N,\N,\N,\N,1,2,2,1),
(3,\N,\N,\N,\N,\N,1,3,3,1),
(4,\N,\N,\N,\N,\N,1,4,4,1),
(5,\N,\N,\N,\N,\N,1,5,5,1),
(6,\N,\N,\N,\N,\N,1,6,6,1),
(7,\N,\N,\N,\N,\N,3,1,1,1),
(8,\N,\N,\N,\N,\N,3,2,2,1),
(9,\N,\N,\N,\N,\N,3,3,3,1),
(10,\N,\N,\N,\N,\N,3,4,4,1)	;
#	TC`tbl_menu_item_log`utf8_general_ci	;
CREATE TABLE `tbl_menu_item_log` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `deleted` tinyint(1) DEFAULT NULL,
  `id` int(11) NOT NULL,
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `create_user_id` int(11) DEFAULT NULL,
  `update_user_id` int(11) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `menu_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `prior` tinyint(4) NOT NULL,
  `visible` tinyint(1) NOT NULL,
  PRIMARY KEY (`log_id`),
  KEY `visible` (`visible`),
  KEY `prior` (`prior`),
  KEY `parent_id` (`parent_id`),
  KEY `menu_id` (`menu_id`),
  KEY `item_id` (`item_id`),
  KEY `create_user_id` (`create_user_id`),
  KEY `update_user_id` (`update_user_id`),
  KEY `deleted` (`deleted`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`tbl_menu_log`utf8_general_ci	;
CREATE TABLE `tbl_menu_log` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `deleted` tinyint(1) DEFAULT NULL,
  `id` int(11) NOT NULL,
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `create_user_id` int(11) DEFAULT NULL,
  `update_user_id` int(11) DEFAULT NULL,
  `value` varchar(255) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`log_id`),
  KEY `deleted` (`deleted`),
  KEY `id` (`id`),
  KEY `create_user_id` (`create_user_id`),
  KEY `update_user_id` (`update_user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8	;
#	TD`tbl_menu_log`utf8_general_ci	;
INSERT INTO `tbl_menu_log` VALUES 
(1,\N,3,1375647119,1375647119,1,1,'1','11'),
(2,\N,3,1375647124,1375647124,1,1,'2','22'),
(3,1,3,1375647127,1375647127,1,1,'2','22'),
(4,\N,4,1375647337,1375647337,1,1,'1','1'),
(5,\N,4,1375647342,1375647342,1,1,'2','22'),
(6,1,4,1375647345,1375647345,1,1,'2','22'),
(7,\N,3,1375692666,1375692666,1,1,'Main page','Главная страница')	;
#	TC`tbl_migration`utf8_general_ci	;
CREATE TABLE `tbl_migration` (
  `version` varchar(255) CHARACTER SET latin1 NOT NULL,
  `apply_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`tbl_migration`utf8_general_ci	;
INSERT INTO `tbl_migration` VALUES 
('m110805_153437_installYiiUser',1374928483),
('m110810_162301_userTimestampFix',1374928483)	;
#	TC`tbl_organization`utf8_general_ci	;
CREATE TABLE `tbl_organization` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `create_user_id` int(11) DEFAULT NULL,
  `update_user_id` int(11) DEFAULT NULL,
  `organization_type_id` int(11) NOT NULL,
  `organization_group_id` int(11) NOT NULL,
  `organization_region_id` int(11) NOT NULL,
  `value` varchar(255) NOT NULL,
  `description` text,
  PRIMARY KEY (`id`),
  KEY `create_user_id` (`create_user_id`),
  KEY `update_user_id` (`update_user_id`),
  KEY `organization_type_id` (`organization_type_id`),
  KEY `organization_group_id` (`organization_group_id`),
  KEY `organization_region_id` (`organization_region_id`),
  CONSTRAINT `tbl_organization_ibfk_5` FOREIGN KEY (`create_user_id`) REFERENCES `tbl_users` (`id`),
  CONSTRAINT `tbl_organization_ibfk_6` FOREIGN KEY (`update_user_id`) REFERENCES `tbl_users` (`id`),
  CONSTRAINT `tbl_organization_ibfk_7` FOREIGN KEY (`organization_type_id`) REFERENCES `tbl_organization_type` (`id`),
  CONSTRAINT `tbl_organization_ibfk_8` FOREIGN KEY (`organization_group_id`) REFERENCES `tbl_organization_group` (`id`),
  CONSTRAINT `tbl_organization_ibfk_9` FOREIGN KEY (`organization_region_id`) REFERENCES `tbl_organization_region` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8	;
#	TD`tbl_organization`utf8_general_ci	;
INSERT INTO `tbl_organization` VALUES 
(1,1374951193,1375453730,1,1,1,1,1,'АтомСпецСервис',''),
(2,1374951205,1375027053,1,1,1,1,1,'«NUKEM Technologies GmbH», Германия',''),
(3,1375003924,1375027068,1,1,1,1,1,'РНЦ «Курчатовский институт», Москва',''),
(4,1375027080,1375500301,1,1,1,1,1,'Институты «Атомэнергопроект»: Москва, СПб, Нижний Новгород, Волгоград',''),
(5,1375027136,1375027136,1,1,1,1,1,'Фирма «BROKK», Швеция',''),
(6,1375027144,1375027144,1,1,1,1,1,'ЗАО «Диаконт», Санкт-Петербург',''),
(7,1375027154,1375027154,1,1,1,1,1,'ОАО «ОКБМ Африкантов»',''),
(8,1375027162,1375027162,1,1,1,1,1,'ОАО НПО «ВНИИПТМАШ», Москва',''),
(9,1375027170,1375027170,1,1,1,1,1,'НТЦ «Техноцентр» ЮФУ',''),
(10,1375027177,1375027177,1,1,1,1,1,'ОАО НПО «ЦНИИТМАШ»',''),
(11,1375027186,1375027186,1,1,1,1,1,'ОАО «ВНИИАЭС»',''),
(12,1375027194,1375027194,1,1,1,1,1,'ОАО «Атоммашэкспорт»',''),
(13,1375027202,1375027202,1,1,1,1,1,'ООО «НЗХК-Инструмент»',''),
(14,1375027210,1375027210,1,1,1,1,1,'ООО «Промэнергокомплект»',''),
(15,1375027218,1375027218,1,1,1,1,1,'ОАО ОКБ «Гидропресс»',''),
(16,1375027226,1375027226,1,1,1,1,1,'ООО «Полесье»',''),
(17,1375027234,1375027234,1,1,1,1,1,'ООО «Танаис»',''),
(18,1375105035,1375105035,1,1,1,1,1,'Фирма «ANSALDO NUCLEARE», Италия ',''),
(22,1375454274,1375454274,1,1,3,1,1,'Автошкола, НОУ УЦ',''),
(24,1375504871,1375506239,1,1,2,2,2,'222222',''),
(25,1375529407,1375529407,1,1,3,1,1,'1000web','')	;
#	TC`tbl_organization_contact`utf8_general_ci	;
CREATE TABLE `tbl_organization_contact` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `create_user_id` int(11) DEFAULT NULL,
  `update_user_id` int(11) DEFAULT NULL,
  `organization_id` int(11) NOT NULL,
  `contact_type_id` int(11) NOT NULL,
  `value` varchar(255) NOT NULL,
  `description` text,
  PRIMARY KEY (`id`),
  KEY `contact_type_id` (`contact_type_id`),
  KEY `organization_id` (`organization_id`),
  KEY `create_user_id` (`create_user_id`),
  KEY `update_user_id` (`update_user_id`),
  CONSTRAINT `tbl_organization_contact_ibfk_3` FOREIGN KEY (`contact_type_id`) REFERENCES `tbl_contact_type` (`id`),
  CONSTRAINT `tbl_organization_contact_ibfk_4` FOREIGN KEY (`organization_id`) REFERENCES `tbl_organization` (`id`),
  CONSTRAINT `tbl_organization_contact_ibfk_5` FOREIGN KEY (`create_user_id`) REFERENCES `tbl_users` (`id`),
  CONSTRAINT `tbl_organization_contact_ibfk_6` FOREIGN KEY (`update_user_id`) REFERENCES `tbl_users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8	;
#	TD`tbl_organization_contact`utf8_general_ci	;
INSERT INTO `tbl_organization_contact` VALUES 
(1,1375106016,1375106016,1,1,1,5,'Россия, 344037, г. Ростов-на-Дону, пр. Шолохова, д.17',''),
(2,1375106167,1375106167,1,1,1,7,'Россия, 347469, Ростовская обл., г. Волгодонск, улица 8-я Заводская, 23',''),
(3,1375106197,1375106197,1,1,1,6,'Россия, 347360, Ростовская обл., г. Волгодонск, Главпочтамт, а/я 1311',''),
(4,1375106220,1375106220,1,1,1,3,'+7 (8639) 277-999',''),
(5,1375106231,1375106231,1,1,1,4,'+7 (8639) 277-999',''),
(6,1375106251,1375106251,1,1,1,1,'dezaktiv@mail.ru',''),
(7,1375106265,1375106265,1,1,1,1,'kto-acc@mail.ru',''),
(8,1375530607,1375538251,1,1,25,6,'Волгодонск, ул.Ленина','')	;
#	TC`tbl_organization_contact_log`utf8_general_ci	;
CREATE TABLE `tbl_organization_contact_log` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `id` int(11) NOT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `create_user_id` int(11) DEFAULT NULL,
  `update_user_id` int(11) DEFAULT NULL,
  `organization_id` int(11) NOT NULL,
  `contact_type_id` int(11) NOT NULL,
  `value` varchar(255) NOT NULL,
  `description` text,
  PRIMARY KEY (`log_id`),
  KEY `contact_type_id` (`contact_type_id`),
  KEY `organization_id` (`organization_id`),
  KEY `create_user_id` (`create_user_id`),
  KEY `update_user_id` (`update_user_id`),
  KEY `id` (`id`),
  KEY `deleted` (`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8	;
#	TD`tbl_organization_contact_log`utf8_general_ci	;
INSERT INTO `tbl_organization_contact_log` VALUES 
(1,8,\N,1375530607,1375530607,1,1,25,6,'Волгодонск',''),
(2,8,\N,1375538251,1375538251,1,1,25,6,'Волгодонск, ул.Ленина','')	;
#	TC`tbl_organization_group`utf8_general_ci	;
CREATE TABLE `tbl_organization_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `create_user_id` int(11) DEFAULT NULL,
  `update_user_id` int(11) DEFAULT NULL,
  `value` varchar(255) NOT NULL,
  `description` text,
  PRIMARY KEY (`id`),
  KEY `create_user_id` (`create_user_id`),
  KEY `update_user_id` (`update_user_id`),
  CONSTRAINT `tbl_organization_group_ibfk_1` FOREIGN KEY (`create_user_id`) REFERENCES `tbl_users` (`id`),
  CONSTRAINT `tbl_organization_group_ibfk_2` FOREIGN KEY (`update_user_id`) REFERENCES `tbl_users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8	;
#	TD`tbl_organization_group`utf8_general_ci	;
INSERT INTO `tbl_organization_group` VALUES 
(1,1,1375628274,1,1,'Основная ',''),
(2,1,1375451413,1,1,'Группа 2',''),
(3,1,1375451425,1,1,'Группа 3','')	;
#	TC`tbl_organization_group_log`utf8_general_ci	;
CREATE TABLE `tbl_organization_group_log` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `id` int(11) NOT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `create_user_id` int(11) DEFAULT NULL,
  `update_user_id` int(11) DEFAULT NULL,
  `value` varchar(255) NOT NULL,
  `description` text,
  PRIMARY KEY (`log_id`),
  KEY `create_user_id` (`create_user_id`),
  KEY `update_user_id` (`update_user_id`),
  KEY `id` (`id`),
  KEY `deleted` (`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8	;
#	TD`tbl_organization_group_log`utf8_general_ci	;
INSERT INTO `tbl_organization_group_log` VALUES 
(1,4,\N,1375185402,1375185402,1,1,'333','333'),
(2,4,\N,1375185407,1375185407,1,1,'333333','333333'),
(3,4,1,1375185410,1375185410,1,1,'333333','333333'),
(4,1,\N,1375451400,1375451400,1,1,'Основная группа ',''),
(5,2,\N,1375451413,1375451413,1,1,'Группа 2',''),
(6,3,\N,1375451425,1375451425,1,1,'Группа 3',''),
(7,1,\N,1375628274,1375628274,1,1,'Основная ','')	;
#	TC`tbl_organization_log`utf8_general_ci	;
CREATE TABLE `tbl_organization_log` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `id` int(11) NOT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `create_user_id` int(11) DEFAULT NULL,
  `update_user_id` int(11) DEFAULT NULL,
  `organization_type_id` int(11) NOT NULL,
  `organization_group_id` int(11) NOT NULL,
  `organization_region_id` int(11) NOT NULL,
  `value` varchar(255) NOT NULL,
  `description` text,
  PRIMARY KEY (`log_id`),
  KEY `create_user_id` (`create_user_id`),
  KEY `update_user_id` (`update_user_id`),
  KEY `organization_type_id` (`organization_type_id`),
  KEY `organization_group_id` (`organization_group_id`),
  KEY `organization_region_id` (`organization_region_id`),
  KEY `id` (`id`),
  KEY `deleted` (`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8	;
#	TD`tbl_organization_log`utf8_general_ci	;
INSERT INTO `tbl_organization_log` VALUES 
(1,19,\N,1375184701,1375184701,1,1,1,1,1,'111111111',''),
(2,19,\N,1375184709,1375184709,1,1,1,1,1,'2222','2222222'),
(3,19,1,1375184713,1375184713,1,1,1,1,1,'2222','2222222'),
(4,20,\N,1375212709,1375212709,1,1,1,1,1,'1111',''),
(5,21,\N,1375442833,1375442833,1,1,1,1,1,'11111','1111'),
(6,21,1,1375442874,1375442874,1,1,1,1,1,'11111','1111'),
(7,20,1,1375442885,1375442885,1,1,1,1,1,'1111',''),
(8,1,\N,1375452422,1375452422,1,1,1,1,1,'АтомСпецСервис',''),
(9,1,\N,1375453171,1375453171,1,1,2,2,3,'АтомСпецСервис',''),
(10,1,\N,1375453181,1375453181,1,1,1,1,1,'АтомСпецСервис',''),
(11,1,\N,1375453202,1375453202,1,1,2,2,3,'АтомСпецСервис',''),
(12,1,\N,1375453213,1375453213,1,1,1,1,1,'АтомСпецСервис',''),
(13,1,\N,1375453730,1375453730,1,1,1,1,1,'АтомСпецСервис',''),
(14,22,\N,1375454274,1375454274,1,1,3,1,1,'Автошкола, НОУ УЦ',''),
(15,4,\N,1375476079,1375476079,1,1,1,2,1,'Институты «Атомэнергопроект»: Москва, СПб, Нижний Новгород, Волгоград',''),
(16,4,\N,1375500301,1375500301,1,1,1,1,1,'Институты «Атомэнергопроект»: Москва, СПб, Нижний Новгород, Волгоград',''),
(17,23,\N,1375504579,1375504579,1,1,2,3,2,'123',''),
(18,23,1,1375504590,1375504590,1,1,2,3,2,'123',''),
(19,24,\N,1375504871,1375504871,1,1,2,2,2,'222',''),
(20,24,\N,1375506210,1375506210,1,1,1,1,3,'333',''),
(21,24,\N,1375506239,1375506239,1,1,2,2,2,'222222',''),
(22,25,\N,1375529407,1375529407,1,1,3,1,1,'1000web','')	;
#	TC`tbl_organization_region`utf8_general_ci	;
CREATE TABLE `tbl_organization_region` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `create_user_id` int(11) DEFAULT NULL,
  `update_user_id` int(11) DEFAULT NULL,
  `value` varchar(255) NOT NULL,
  `description` text,
  PRIMARY KEY (`id`),
  KEY `create_user_id` (`create_user_id`),
  KEY `update_user_id` (`update_user_id`),
  CONSTRAINT `tbl_organization_region_ibfk_1` FOREIGN KEY (`create_user_id`) REFERENCES `tbl_users` (`id`),
  CONSTRAINT `tbl_organization_region_ibfk_2` FOREIGN KEY (`update_user_id`) REFERENCES `tbl_users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8	;
#	TD`tbl_organization_region`utf8_general_ci	;
INSERT INTO `tbl_organization_region` VALUES 
(1,1,1,1,1,'Россия',''),
(2,1,1,1,1,'Зарубежье',''),
(3,1375087150,1375087150,1,1,'Украина','')	;
#	TC`tbl_organization_region_log`utf8_general_ci	;
CREATE TABLE `tbl_organization_region_log` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `id` int(11) NOT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `create_user_id` int(11) DEFAULT NULL,
  `update_user_id` int(11) DEFAULT NULL,
  `value` varchar(255) NOT NULL,
  `description` text,
  PRIMARY KEY (`log_id`),
  KEY `create_user_id` (`create_user_id`),
  KEY `update_user_id` (`update_user_id`),
  KEY `id` (`id`),
  KEY `deleted` (`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8	;
#	TD`tbl_organization_region_log`utf8_general_ci	;
INSERT INTO `tbl_organization_region_log` VALUES 
(1,4,\N,1375185845,1375185845,1,1,'444','444'),
(2,4,\N,1375185850,1375185850,1,1,'444444','444444'),
(3,4,1,1375185852,1375185852,1,1,'444444','444444')	;
#	TC`tbl_organization_type`utf8_general_ci	;
CREATE TABLE `tbl_organization_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `create_user_id` int(11) DEFAULT NULL,
  `update_user_id` int(11) DEFAULT NULL,
  `value` varchar(255) NOT NULL,
  `description` text,
  PRIMARY KEY (`id`),
  KEY `create_user_id` (`create_user_id`),
  KEY `update_user_id` (`update_user_id`),
  CONSTRAINT `tbl_organization_type_ibfk_1` FOREIGN KEY (`create_user_id`) REFERENCES `tbl_users` (`id`),
  CONSTRAINT `tbl_organization_type_ibfk_2` FOREIGN KEY (`update_user_id`) REFERENCES `tbl_users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8	;
#	TD`tbl_organization_type`utf8_general_ci	;
INSERT INTO `tbl_organization_type` VALUES 
(1,1,1,1,1,'Партнер',''),
(2,1,1,1,1,'Заказчик',''),
(3,1,1,1,1,'Поставщик','')	;
#	TC`tbl_organization_type_log`utf8_general_ci	;
CREATE TABLE `tbl_organization_type_log` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `id` int(11) NOT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `create_user_id` int(11) DEFAULT NULL,
  `update_user_id` int(11) DEFAULT NULL,
  `value` varchar(255) NOT NULL,
  `description` text,
  PRIMARY KEY (`log_id`),
  KEY `create_user_id` (`create_user_id`),
  KEY `update_user_id` (`update_user_id`),
  KEY `deleted` (`deleted`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8	;
#	TD`tbl_organization_type_log`utf8_general_ci	;
INSERT INTO `tbl_organization_type_log` VALUES 
(1,4,\N,1375186136,1375186136,1,1,'111','111'),
(2,4,\N,1375186141,1375186141,1,1,'111222','111222'),
(3,4,1,1375186144,1375186144,1,1,'111222','111222')	;
#	TC`tbl_product`utf8_general_ci	;
CREATE TABLE `tbl_product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `create_user_id` int(11) DEFAULT NULL,
  `update_user_id` int(11) DEFAULT NULL,
  `product_type_id` int(11) NOT NULL,
  `value` varchar(255) NOT NULL,
  `description` text,
  PRIMARY KEY (`id`),
  KEY `create_user_id` (`create_user_id`),
  KEY `update_user_id` (`update_user_id`),
  KEY `product_type_id` (`product_type_id`),
  CONSTRAINT `tbl_product_ibfk_4` FOREIGN KEY (`create_user_id`) REFERENCES `tbl_users` (`id`),
  CONSTRAINT `tbl_product_ibfk_5` FOREIGN KEY (`update_user_id`) REFERENCES `tbl_users` (`id`),
  CONSTRAINT `tbl_product_ibfk_6` FOREIGN KEY (`product_type_id`) REFERENCES `tbl_product_type` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`tbl_product_type`utf8_general_ci	;
CREATE TABLE `tbl_product_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `create_user_id` int(11) DEFAULT NULL,
  `update_user_id` int(11) DEFAULT NULL,
  `value` varchar(255) NOT NULL,
  `description` text,
  PRIMARY KEY (`id`),
  KEY `create_user_id` (`create_user_id`),
  KEY `update_user_id` (`update_user_id`),
  CONSTRAINT `tbl_product_type_ibfk_1` FOREIGN KEY (`create_user_id`) REFERENCES `tbl_users` (`id`),
  CONSTRAINT `tbl_product_type_ibfk_2` FOREIGN KEY (`update_user_id`) REFERENCES `tbl_users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8	;
#	TD`tbl_product_type`utf8_general_ci	;
INSERT INTO `tbl_product_type` VALUES 
(1,1375186888,1375186888,1,1,'111',''),
(2,1375186892,1375186892,1,1,'222',''),
(3,1375186895,1375186895,1,1,'333','')	;
#	TC`tbl_product_type_log`utf8_general_ci	;
CREATE TABLE `tbl_product_type_log` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `deleted` tinyint(1) DEFAULT NULL,
  `id` int(11) NOT NULL,
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `create_user_id` int(11) DEFAULT NULL,
  `update_user_id` int(11) DEFAULT NULL,
  `value` varchar(255) NOT NULL,
  `description` text,
  PRIMARY KEY (`log_id`),
  KEY `create_user_id` (`create_user_id`),
  KEY `update_user_id` (`update_user_id`),
  KEY `deleted` (`deleted`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8	;
#	TD`tbl_product_type_log`utf8_general_ci	;
INSERT INTO `tbl_product_type_log` VALUES 
(1,\N,4,1375188892,1375188892,1,1,'555','555'),
(2,\N,4,1375188897,1375188897,1,1,'555666','555666'),
(3,1,4,1375188899,1375188899,1,1,'555666','555666')	;
#	TC`tbl_profiles`utf8_general_ci	;
CREATE TABLE `tbl_profiles` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  CONSTRAINT `user_profile_id` FOREIGN KEY (`user_id`) REFERENCES `tbl_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8	;
#	TD`tbl_profiles`utf8_general_ci	;
INSERT INTO `tbl_profiles` VALUES 
(1,'Евгений','Дмитриченко'),
(3,'test','test'),
(4,'Менеджер',''),
(5,'Demo','Demo')	;
#	TC`tbl_profiles_fields`utf8_general_ci	;
CREATE TABLE `tbl_profiles_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `varname` varchar(50) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  `field_type` varchar(50) NOT NULL DEFAULT '',
  `field_size` int(3) NOT NULL DEFAULT '0',
  `field_size_min` int(3) NOT NULL DEFAULT '0',
  `required` int(1) NOT NULL DEFAULT '0',
  `match` varchar(255) NOT NULL DEFAULT '',
  `range` varchar(255) NOT NULL DEFAULT '',
  `error_message` varchar(255) NOT NULL DEFAULT '',
  `other_validator` text,
  `default` varchar(255) NOT NULL DEFAULT '',
  `widget` varchar(255) NOT NULL DEFAULT '',
  `widgetparams` text,
  `position` int(3) NOT NULL DEFAULT '0',
  `visible` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8	;
#	TD`tbl_profiles_fields`utf8_general_ci	;
INSERT INTO `tbl_profiles_fields` VALUES 
(1,'first_name','Имя','VARCHAR',255,3,2,'','','Неверное имя (длина должна быть от 3 до 50 символов).','','','','',1,3),
(2,'last_name','Фамилия','VARCHAR',255,3,2,'','','Неверная фамилия (длина должна быть от 3 до 50 символов).','','','','',2,3)	;
#	TC`tbl_task`utf8_general_ci	;
CREATE TABLE `tbl_task` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `create_user_id` int(11) DEFAULT NULL,
  `update_user_id` int(11) DEFAULT NULL,
  `task_type_id` int(11) NOT NULL,
  `datetime` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `value` varchar(255) NOT NULL,
  `description` text,
  PRIMARY KEY (`id`),
  KEY `create_user_id` (`create_user_id`),
  KEY `update_user_id` (`update_user_id`),
  KEY `user_id` (`user_id`),
  KEY `task_type_id` (`task_type_id`),
  CONSTRAINT `tbl_task_ibfk_1` FOREIGN KEY (`create_user_id`) REFERENCES `tbl_users` (`id`),
  CONSTRAINT `tbl_task_ibfk_2` FOREIGN KEY (`update_user_id`) REFERENCES `tbl_users` (`id`),
  CONSTRAINT `tbl_task_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `tbl_users` (`id`),
  CONSTRAINT `tbl_task_ibfk_4` FOREIGN KEY (`task_type_id`) REFERENCES `tbl_task_type` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`tbl_task_type`utf8_general_ci	;
CREATE TABLE `tbl_task_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `create_user_id` int(11) DEFAULT NULL,
  `update_user_id` int(11) DEFAULT NULL,
  `value` varchar(255) NOT NULL,
  `description` text,
  PRIMARY KEY (`id`),
  KEY `create_user_id` (`create_user_id`),
  KEY `update_user_id` (`update_user_id`),
  CONSTRAINT `tbl_task_type_ibfk_1` FOREIGN KEY (`create_user_id`) REFERENCES `tbl_users` (`id`),
  CONSTRAINT `tbl_task_type_ibfk_2` FOREIGN KEY (`update_user_id`) REFERENCES `tbl_users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8	;
#	TD`tbl_task_type`utf8_general_ci	;
INSERT INTO `tbl_task_type` VALUES 
(1,1375089924,1375089924,1,1,'Веха','Ключевой момент в ходе выполнения проекта, общая граница двух и более задач.'),
(2,1375090023,1375090023,1,1,'Email входящий','Присланное клиентом письмо по электронной почте.'),
(3,1375090056,1375090056,1,1,'Email исходящий','Нужно отправить клиенту письмо по электронной почте.'),
(4,1375090174,1375090174,1,1,'Контроль исполнения','Контроль исполнения какой-либо задачи.'),
(5,1375090200,1375090230,1,1,'Звонок входящий','Звонок от клиента.'),
(6,1375090215,1375090215,1,1,'Звонок исходящий','Исходящий звонок клиенту.'),
(7,1375090245,1375090245,1,1,'Встреча','Встреча с клиентом.'),
(8,1375090310,1375090669,1,1,'Письмо входящее','Входящее письмо от клиента.'),
(9,1375090325,1375090325,1,1,'Письмо исходящее','Отправка письма клиенту.')	;
#	TC`tbl_task_type_log`utf8_general_ci	;
CREATE TABLE `tbl_task_type_log` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `deleted` tinyint(1) DEFAULT NULL,
  `id` int(11) NOT NULL,
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `create_user_id` int(11) DEFAULT NULL,
  `update_user_id` int(11) DEFAULT NULL,
  `value` varchar(255) NOT NULL,
  `description` text,
  PRIMARY KEY (`log_id`),
  KEY `create_user_id` (`create_user_id`),
  KEY `update_user_id` (`update_user_id`),
  KEY `deleted` (`deleted`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8	;
#	TD`tbl_task_type_log`utf8_general_ci	;
INSERT INTO `tbl_task_type_log` VALUES 
(1,\N,10,1375188850,1375188850,1,1,'1111','111'),
(2,\N,10,1375188855,1375188855,1,1,'222','222'),
(3,1,10,1375188858,1375188858,1,1,'222','222')	;
#	TC`tbl_users`utf8_general_ci	;
CREATE TABLE `tbl_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL DEFAULT '',
  `password` varchar(128) NOT NULL DEFAULT '',
  `email` varchar(128) NOT NULL DEFAULT '',
  `activkey` varchar(128) NOT NULL DEFAULT '',
  `superuser` int(1) NOT NULL DEFAULT '0',
  `status` int(1) NOT NULL DEFAULT '0',
  `create_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `lastvisit_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_username` (`username`),
  UNIQUE KEY `user_email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8	;
#	TD`tbl_users`utf8_general_ci	;
INSERT INTO `tbl_users` VALUES 
(1,'admin','21232f297a57a5a743894a0e4a801fc3','admin@1000web.ru','548fe0520f05bfc6f198d5e215e663a6',1,1,'2013-07-27 16:34:43','2013-08-05 09:43:32'),
(3,'test','098f6bcd4621d373cade4e832627b4f6','test@1000web.ru','14bb47bd3f709e5e725a3857e42d1934',0,1,'2013-07-28 19:23:42','2013-07-28 18:15:42'),
(4,'manager','1d0258c2440a8d19e716292b231e3190','manager@1000web.ru','6c53d52a7f38a23155b5159b2bc1eb7c',0,1,'2013-08-04 18:07:54','2013-08-04 16:08:03'),
(5,'demo','fe01ce2a7fbac8fafaed7c982a04e229','demo@1000web.ru','a707be1503afd9dd1a79dde620577941',0,1,'2013-08-04 18:13:17','2013-08-04 16:14:11')	;
